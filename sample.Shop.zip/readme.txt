SAP Fiori Reference Application, demonstrating a shop scenario on the EPM model.
